package StaffImageEditor;

public class DisplayRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new FunImageDisplayer();
	}

}
